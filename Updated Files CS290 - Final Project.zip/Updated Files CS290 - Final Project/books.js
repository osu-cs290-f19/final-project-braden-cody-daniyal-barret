const Books = [{
        "name": "Killing Hemingway",
        "img": "https://99designs-start-attachments.imgix.net/alchemy-pictures/2016%2F02%2F12%2F00%2F05%2F05%2F910db405-6bd4-4a5d-bce7-c2e3135dc5e6%2F449070_WAntoneta_55908c_killing.png?auto=format&ch=Width%2CDPR&fm=png&w=600&h=600",
        "rate" : 4,
        "author": 'author1',
        "publishedOn" : '10 Nov'
    },
    {
        "name": "Born Of Water",
        "img": "https://i1.wp.com/justwordministries.com/wp-content/uploads/2019/01/Upright-Hard-Book-Mockup-Right-tilt.png?fit=2000%2C2000&ssl=1",
        "rate" : 5,
        "author": 'author2',
        "publishedOn" : '10 Nov'
    },
    {
        "name": "Million Dollar",
        "img": "https://99designs-start-attachments.imgix.net/alchemy-pictures/2017%2F06%2F20%2F00%2F03%2F14%2F87b6c6e0-93f5-41eb-ae68-7dc1aed816d8%2Fbookleftalign.png?auto=format&ch=Width%2CDPR&fm=png",
        "rate" : 3,
        "author": 'author3',
        "publishedOn" : '10 Nov'
    },
    {
        "name": "Principles To Fortune",
        "img": "https://principlestofortune.com/wp-content/uploads/Principles-To-Fortune-Book-.jpg",
        "rate" : 2,
        "author": 'author4',
        "publishedOn" : '10 Nov'
    }
]